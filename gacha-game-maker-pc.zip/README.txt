가챠 게임 메이커 · PC 서버
==========================
PC에서 게임을 띄우고 휴대폰으로 접속해요. 게임 데이터는 이 PC의 data 폴더에 게임별·종류별 JSON으로 저장돼요.
  data/index.json            게임 목록
  data/<게임id>/chars.json    캐릭터      chapters.json  시나리오(챕터·스테이지·대본)   world.json  세계관
              meta.json  lib.json  threads.json  events.json  banners.json  prog.json(진행) …  game.json(나머지)
  ggm-data/                  연결 키(key.txt), 그림·소리(blobs), 저장 백업(history), 기기 설정(state.json)
휴대폰·브라우저 안의 저장(IndexedDB)은 캐시예요. 저장할 때마다 몇 초 안에 PC의 data 폴더로 자동으로 올라가고, 새 기기는 여기서 받아 와요.
예전 버전 서버의 ggm-data/state.json은 처음 켤 때 data 폴더로 자동으로 나눠요(원본은 ggm-data/history에 복사).
내 PC의 ComfyUI(127.0.0.1:8188)나 Ollama(127.0.0.1:11434)도 휴대폰에서 그대로 쓸 수 있어요.

1. Python 3.8 이상을 설치해요 (https://www.python.org/downloads/ , 설치 때 Add to PATH 체크).
2. Windows: "PC서버-시작.bat" 더블클릭 / Mac·Linux: start.sh 실행.
3. 브라우저에 QR 코드가 뜨면 휴대폰 카메라로 찍어요. (처음엔 cloudflared를 자동으로 받아요)
4. 게임은 이 PC에 저장되니 휴대폰에서는 매번 QR로 들어오면 돼요. 안드로이드 앱에서는 설정 → PC 서버에 주소를 붙여 넣어요.
   - 아이폰: 기본 카메라 앱으로 QR을 비추고, 뜨는 주소를 눌러 Safari로 열어요. 처음 열면 PC에 저장된 게임을 받아 와요.
   - 아이폰 홈 화면 앱은 Safari와 저장 공간이 따로예요. 바깥 주소(trycloudflare)는 서버를 켤 때마다 바뀌니 홈 화면 추가보다 QR을 다시 찍는 게 편해요.
   - 같은 와이파이에서는 QR 창 아래의 두 번째 QR(같은 와이파이용, 주소가 바뀌지 않아요)을 써도 돼요.

- 검은 창을 닫으면 외부 주소가 사라져요. 다음 실행 때는 새 주소·새 QR이 나와요(데이터는 그대로).
- 주소 끝의 pc=... 는 비밀 키예요. 다른 사람에게 보내지 마세요. 키를 바꾸려면 ggm-data/key.txt를 지우고 다시 실행해요.
- 같은 와이파이에서만 쓸 거면: PC서버-시작.bat --no-tunnel
- 게임이 초기화됐거나 진행이 사라졌으면: 게임의 설정 → PC 서버 → 'PC 백업에서 되살리기'. 백업은 ggm-data/history 폴더에 있어요(최근 20번 + 크게 줄어들기 전 저장 10개).

2026.10.22.2 저장 보호
- 동시에 두 기기에서 저장하면 나중 요청이 최신 기록을 덮지 않도록 충돌을 알립니다. 같은 초에 저장해도 백업이 각각 남습니다.
- 기존 PC 서버를 사용하는 경우 서버 창을 닫고 ggm-server.py를 새 파일로 교체한 뒤 다시 실행하세요. ggm-data 폴더와 key.txt는 지우거나 교체하지 마세요.
- 새 앱 코드는 이전 서버와도 연결되지만, 서버의 동시 저장 보호는 새 PC 서버로 교체해야 적용됩니다.

2026.11.03.1 데이터 폴더
- 게임 데이터를 data/<게임id>/<종류>.json으로 나눠 저장합니다. 바뀐 종류의 파일만 다시 씁니다.
- 앱에서 지운 게임의 폴더는 지우지 않고 ggm-data/history/deleted-* 로 옮깁니다.
- --no-update: 켤 때 GitHub에서 www/를 받지 않고 그대로 씁니다(직접 빌드한 앱으로 시험할 때). GGM_REPO=주인/저장소 로 받을 곳을 바꿀 수 있어요.
- GGM_DATA_DIR=경로 로 data 폴더 위치를 바꿀 수 있어요.

2026.11.03.2
- 켤 때 받는 앱(www/)을 이 포크(mgsongct/gacha-game-maker)에서 받아요. 원본 zip의 서버는 원본 앱을 받아서 이 포크의 기능(데이터 폴더 자동 저장 등)이 빠져 있었어요. 창에 '앱 빌드: …'가 나와서 어떤 버전인지 확인할 수 있어요.
- GGM_BRANCH=브랜치 로 받을 브랜치를 고를 수 있어요(기본 main).
- data 폴더의 JSON을 직접 고치면 새 저장으로 표시돼서 앱이 받아 가요(고친 걸 모르는 기기는 덮어쓰지 못해요). JSON 문법이 틀리면 어느 파일인지 알려 줘요.

2026.11.03.3
- GGM_RAW=주소 로 앱(www/)을 받는 주소를 바꿀 수 있어요(기본 https://raw.githubusercontent.com — 배포본 시험용).
